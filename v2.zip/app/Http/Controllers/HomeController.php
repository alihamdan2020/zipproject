<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Mail\contact;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;


class HomeController extends Controller
{
   public function welcome() {
   $allproducts=DB::table('products')
   ->join('country', 'country.countryId', '=', 'products.countryId')
   ->select('*')
   ->get();
    return view ('welcome',['allproducts'=>$allproducts]);
   }

   public function dipslayCrateItems(){
      
   }
}

