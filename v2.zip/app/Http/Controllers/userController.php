<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use    App\Models\User;
use Illuminate\Support\Facades\DB;
use App\Models\Product;;
use Illuminate\Support\Facades\Mail;
use App\Mail\contact;
use Illuminate\Support\Facades\Hash;

class userController extends Controller
{
    public function index(){
        return view ("login.login");
    }

    public function LogIn(Request $request){
        $request ->validate([
            'name'=>'required',
            'password' => 'required',
         ]);

        $name=$request->input('name');
        $pass=$request->input('password');
        
        $user=DB::table('users')
        ->select('*')
        ->where('name',$name)
        ->where('password',hash::check($pass,'password'))
        ->get();
        
        if(count($user)==1){
        session()->put('user',1);
        return redirect ('/');
        }
        else
        {
        $err="Wrong User Name and Password";
        return redirect()->back()
        ->withErrors(['error'=>$err])
        ->withInput();
        }
    }

    public function signup(){
        return view('login.newuser');
    }
    
    public function logout(){
        session()->pull('user');
        return redirect ('/');
    }

    public function newuser(Request $request){
        $request ->validate([
            'name'=>'required|unique:users',
            'password' => 'required|min:3|max:10',
         ]);

        $newuser = new User();
        $name=$request->input('name');
        $pass=Hash::make($request->input('password'));
        $newuser ->name=$name;
        $newuser ->email=$name."@hotmail.com";
        $newuser->password=$pass;
        $res=$newuser->save();
        $data=[
            "name"=>$name,
            "email" => "ali_hamdane@hotmail.com",
            "message" => "accespted"
         ];
         Mail::to($newuser ->email)->send(new contact($data));
         session()->put('user',1);
         
        return redirect ('/');

/*
        
           
        if(count($user)==1){
        $err="This name already exist";
        return redirect ()->back()
        ->withErrors(['error'=>$err])
        ->withInput();
        }
         
        }*/

    }

    
}
