<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Cookie;



class itemsController extends Controller
{
    
    //i pass a cookie to server from a local storage (see js file)
    //cookie contain array that contain id for each item you have selected
    public function index()
        //expode : conver string seperated by '(cookie) to array
        
    {   
        $first=$_COOKIE['abc'];
       
        $second=json_decode($first,true);
        $countSelectedItem=count($second);
        $associativeArray=[];
        
        for($i=0;$i<$countSelectedItem;$i++){
        $items=DB::table('products')
        ->join('country', 'country.countryId', '=', 'products.countryId')
        ->select('*')
        //code below coz he make a prob from first item that contyain ""
        //so i remove " by function str_replace
        ->where ('id',"=",$second[$i]['id'])->first();
        array_push($associativeArray,$items);
        }
        
        return view ('items.index',['specitems'=>$associativeArray]);
        
        
        
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      
    }
    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

  
    public function destroy($id)
    {
        
    }

    public static function showCart($items){

        $result ="<div class='content'>
                    <div class='headeofcontent'>
                    <h1>All</h1>
                    <p>Your Items</p>
                    </div>
        <div class='allitems'>";
        foreach ($items as $item){
        $result=$result."<div class='item'>
                <div class='itemimage'>
                <img src='images/" .$item ->image."')>
                </div>
                <div class='iteminfo'>
                <span>".$item-> productName."</span>
                <span>".$item ->productPrice." $</span>
                <a href='#' data-id=".$item->id." class='removeFromCrate'>delete</a>
                <!--
                <form action='".route('items.destroy', $item->id)."' method='POST'>";
                $result.=csrf_field();           
                $result.=method_field('DELETE');
                $result.="<button type='submit'>delete</button>
                </form>
                -->
                </div></div>";
                
        }
        $result.="</div></div>";
        return $result;
}


}
    

