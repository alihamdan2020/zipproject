
<?php
use App\Http\Controllers\itemsController;
?>


<?php $__env->startSection('content'); ?>
<?php echo itemsController::showCart($specitems); ?>
<br><br><br><br><br><br>
<form action="" method="POST">
    <?php echo csrf_field(); ?>
 <button type="submits" title="Confirm">Confirm</button>
</form>

<br>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
Computers page
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/items/index.blade.php ENDPATH**/ ?>