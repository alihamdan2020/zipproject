<ul>
    
    <li><a href="<?php echo e(route('computers.create')); ?>">create new computer</a></li>
    <li><a href="<?php echo e(route('computers.edit',1)); ?>">edit exist computer</a></li>
</ul>

<form action="#">
<input type="text" name="txtid">
<button type="submit">submit</button>
</form><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/index.blade.php ENDPATH**/ ?>