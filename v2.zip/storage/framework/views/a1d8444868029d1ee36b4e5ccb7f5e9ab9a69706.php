
<div class="footer">
jawad
</div>
<?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/footer.blade.php ENDPATH**/ ?>