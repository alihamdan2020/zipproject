<h1>jawad</h1>

<ul>
<?php $__currentLoopData = $allproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>Product Id : <?php echo e($product['id']); ?> - Product Name : <?php echo e($product['productName']); ?> - product Price : <?php echo e($product['productPrice']); ?></li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/products/index.blade.php ENDPATH**/ ?>