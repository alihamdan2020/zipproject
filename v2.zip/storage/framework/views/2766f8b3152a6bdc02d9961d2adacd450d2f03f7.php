<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(url('css/style.css')); ?>" rel="stylesheet"></link>
    <link href="<?php echo e(url('css/fontawesome.min.css')); ?>" rel="stylesheet"></link>
    <link href="<?php echo e(url('css/all.min.css')); ?>" rel="stylesheet"></link>
    
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>
<div class="container">
    <div class="aboveheader">
        <div class="fontawseomicons">
        <?php if(!session()->has('user')): ?>
        <a href="<?php echo e(route('login.index')); ?>"><i class="fas fa-user"></i></a>
        <?php else: ?>
        <a href="<?php echo e(route('logout')); ?>"><i class="fas fa-sign-out-alt"></i></a>
        <?php endif; ?>

        <a href="#"><i class="fas fa-shopping-cart" value=""></i></a>
        </div>
    </div>
    <div class="header">
        <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(url('images/logo.png')); ?>" alt=""></a>
        <ul class="listheader">
            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('computers.index')); ?>">Computers</a></li>
            <li><a href="<?php echo e(route('accessories.index')); ?>">Accessories</a></li>
            <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
            <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
        </ul>
        <div class="burger">
            <span></span>
            <span></span>
            <span></span>

        </div>
    </div>
    <?php if(request()->is('/')): ?>
    <div class="landing">
        <h1>All You need by one visit</h1>
    </div>
    <?php else: ?>
        <?php if(request()->is('computers')): ?>
        <div class="landing">
            <h1>Ommak</h1>
        </div>
        <?php endif; ?>
    <?php endif; ?>
<?php echo $__env->yieldContent('content'); ?>
</div> 
<script src="<?php echo e(url('script/script.js')); ?>"></script>

</body>
</html><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/layout.blade.php ENDPATH**/ ?>