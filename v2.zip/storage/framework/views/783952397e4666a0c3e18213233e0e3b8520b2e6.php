
<?php $__env->startSection('content'); ?>
<style>
    .productdetail{
        display: flex;
        padding:20px;
        font-size: 12px;
    }
    .productinfo{
        border:1px solid green;
        width:50%;
        padding:20px
    }
    .productinfo span{
        color:brown;
    }
    .productinfo p{
        color:#ccc;
        padding-left:15px;
    }
    .productimage{
        width:50%;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .productimage img{
        width:50%;
        max-width: 100%;
    }

</style>
<div class="productdetail">
    <div class="productinfo">
        <span>Product Name</span>
<p><?php echo e($oneproduct-> productName); ?></p>
<span>Product Dexription</span>
<p><?php echo e($oneproduct-> productDesc); ?></p>
<span>Product Price</span>
<p><?php echo e($oneproduct-> productPrice); ?> $</p>
</div>
<div class="productimage">
    <img src="<?php echo e(url('images/' . $oneproduct ->image)); ?>" alt="">
</div>
</div>
<div class="back">
    <a href="<?php echo e(route('computers.index')); ?>">back to computers page</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/computers/show.blade.php ENDPATH**/ ?>