
<?php $__env->startSection('title'); ?>
Edit Existing Computer page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
<div class="formdiv">

    <form action="<?php echo e(route('computers.update', ['computer'=>$comp->id])); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
        <div>
            <label for="computerName">Computer Name</label>
            <input name="computerName" value="<?php echo e($comp->productName); ?>" id="computerName" type="text">
            <span>
                <?php $__errorArgs = ['computerName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
        </div>
        <div>
            <label for="computerPrice">Computer Price</label>
            <input name="computerPrice" value="<?php echo e($comp->productPrice); ?>" id="computerPrice" type="text">
            <span>
                <?php $__errorArgs = ['computerPrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
        </div>
        <div>
            <label for="computerDesc">Computer Description</label>
            <input name="computerDesc" value="<?php echo e($comp->productDesc); ?>" id="computerDesc" type="text">
            <span>
                <?php $__errorArgs = ['computerDesc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
        </div>
        <div>
            <label for="computerCountry">Computer Country</label>
            <select name="computerCountry" id="">
                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($country->countryId); ?>"><?php echo e($country->countryName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            
        </div>

        <div>
            <button type="submit">Submit</button>
        </div>

    </form>
</div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/computers/edit.blade.php ENDPATH**/ ?>