<h1>jm</h1>
<span><?php echo e($oneproduct['productName']); ?></span><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/accessories/show.blade.php ENDPATH**/ ?>