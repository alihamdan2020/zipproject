//press add to cart button
var tot=0;
var cart=document.getElementsByClassName("fa-shopping-cart")[0];
cart.setAttribute("value",0);

var btn = document.getElementsByClassName('button');
btnArray=Array.from(btn);
btnArray.forEach(function(btn){
    btn.addEventListener("click",function(){
        tot=tot+1;
        cart.setAttribute("value",tot);
        alert(cart.getAttribute("value"));
});
});


//




function createItemList(name,value){
    let li=document.createElement('li');
    li.classList.add("pageLink");
    li.setAttribute("data-value",value);
    let linkText=document.createTextNode(name);
    li.appendChild(linkText);
    return li;
}

function hideDiv(a,b,x){
    var p=Array.from(x);
    for(i=a;i<b;i++){
    p[i].style.display="none";
    }
}
function showDiv(a,b,x){
    var p=Array.from(x);
    for(i=a;i<b;i++){
    p[i].style.display="block";
    }
}

//function to display few products(pagination)
function displayDiv() {
     var product=document.querySelectorAll(".product");
     var arrProduct=Array.from(product);
     var listnumber=document.querySelectorAll(".paginationlist");
     var totalNumberOfDiv=product.length;
     var limit=10;

   hideDiv(10,totalNumberOfDiv,product);

   for(i=Math.ceil(product.length/10);i>=1;i--)
    listnumber[0].appendChild(createItemList(i,i));
    
   

   var anch=document.querySelectorAll(".pageLink");
   anchArray=Array.from(anch);
   anchArray.forEach(function(elem){
       elem.addEventListener("click",function(){
       var t=this.getAttribute("data-value");
     
        arrProduct.filter(function(div,index){
            return index<t*10-10 || index>t*10-1;
           }).forEach(function(div){
            div.style.display="none";
           })

        arrProduct.filter(function(div,index){
            return index>=t*10-10 && index<=t*10-1;
           }).forEach(function(div){
            div.style.display="block";
           })
    
   
       })
   
   });
   
}
document.addEventListener("DOMContentLoaded", displayDiv());

