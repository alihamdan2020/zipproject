<?php

use App\Http\Controllers\accessoriesController;
use App\Http\Controllers\adminController;
use App\Http\Controllers\computerController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\itemsController;
use App\Http\Controllers\userController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/',[HomeController::class,"welcome"])->name('home');

route::resource('items',itemsController::class);


Route::resource('computers',computerController::class);

route::resource('accessories',accessoriesController::class);

Route::get("about",function(){
    return view ('about');
})->name('about');

Route::get("/contactus",function(){
    return view ('contactus');
})->name('contact');



Route::resource('admin',adminController::class);
Route::post('admin/check', [adminController::class, 'myfunction'])->name('clickme');

route::resource('login',userController::class);
route::post('search',[userController::class,'LogIn'])->name('login');
route::get('logout',[userController::class,'logout'])->name('logout');
route::get('signup',[userController::class,'signup'])->name('signup');
route::post('add',[userController::class,'newuser'])->name('addnewuser');


