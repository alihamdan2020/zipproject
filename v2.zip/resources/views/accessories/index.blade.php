<?php
use App\Http\Controllers\computerController;
?>

@extends('layout')

@section('content')
<?php echo computerController::displayProducts($allproducts); ?>
@endsection


@section('title')
Accessories page
@endsection