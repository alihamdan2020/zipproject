
<?php
use App\Http\Controllers\itemsController;
?>
@extends('layout')

@section('content')
<?php echo itemsController::showCart($specitems); ?>
<br><br><br><br><br><br>
<form action="" method="POST">
    @csrf
 <button type="submits" title="Confirm">Confirm</button>
</form>

<br>

</div>

@endsection


@section('title')
Computers page
@endsection

