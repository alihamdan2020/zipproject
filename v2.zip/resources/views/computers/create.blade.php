@extends('layout')
@section('title')
New Computer page
@endsection

@section('content')
<div class="content">
<div class="formdiv">

    <form action="{{route('computers.store')}}" method="post">
    @csrf
        <div>
            <label for="computerName">Computer Name</label>
            <input name="computerName" value="{{old('computerName')}}" id="computerName" type="text">
            <span>
                @error('computerName')
                {{$message}}
                @enderror
            </span>
        </div>
        <div>
            <label for="computerPrice">Computer Price</label>
            <input name="computerPrice" value="{{old('computerPrice')}}" id="computerPrice" type="text">
            <span>
                @error('computerPrice')
                {{$message}}
                @enderror
            </span>
        </div>
        <div>
            <label for="computerDesc">Computer Description</label>
            <input name="computerDesc" value="{{old('computerDesc')}}" id="computerDesc" type="text">
            <span>
                @error('computerDesc')
                {{$message}}
                @enderror
            </span>
        </div>
        <div>
            <label for="computerCountry">Computer Country</label>
            <select name="computerCountry" id="">
                @foreach($countries as $country)
                <option value="{{$country->countryId}}">{{$country->countryName}}</option>
                @endforeach
            </select>
            
        </div>

        <div>
            <button type="submit">Submit</button>
        </div>

    </form>
</div>
</div>
@include('footer')
@endsection




