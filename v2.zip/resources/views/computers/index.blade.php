<?php
use App\Http\Controllers\computerController;
?>
@extends('layout')

@section('content')
<?php echo computerController::displayProducts($allproducts); ?>
@include('footer')
@endsection


@section('title')
Computers page
@endsection