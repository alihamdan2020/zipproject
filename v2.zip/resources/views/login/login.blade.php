@extends('layout')

@section('content')
<div class="content">
<h1>Log In</h1>    
<div class="formdiv">
    <form action="{{route('login')}}" method="post">
    @csrf
        <div>
            <label for="name">User Name</label>
            <input name="name" value="{{old('name')}}" id="name" type="text">
            <span>
                @error('name')
                {{$message}}
                @enderror
            </span>
        </div>
        <div>
            <label for="password">Password</label>
            <input name="password" value="{{old('password')}}" id="password" type="password">
            <span>
                @error('password')
                {{$message}}
                @enderror
            </span>
        </div>
        <div>
            <button type="submit">Submit</button>
            <span><a href="{{route('signup')}}">new register</a></span>
        </div>
        <div>
            <span class="errmsg">
            @error('error')
                {{$message}}
            @enderror
            </span>
        </div>

    </form>
</div>
</div>
@include('footer')
@endsection
