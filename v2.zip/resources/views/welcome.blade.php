@extends('layout')
<?php
use App\Http\Controllers\computerController;
?>

@section('title')
Index page
@endsection

@section('content')
<?php echo computerController::displayProducts($allproducts,"Products"); ?>

<?php echo computerController::displaySection(); ?>

</div>

@endsection

