@extends('layout')


@section('title')
Index page
@endsection

@section('content')
<div class="content">
    <div class="headeofcontent">
            <h1>All</h1>
            <p> Categories</p>
    </div>
    <div class="allproducts">
    @foreach ($allproducts as $product)
    <div class="product">
    <div class="productimage">
    <img src="{{url('images/' . $product['image'])}}" alt="">
    </div>
    <div class="productinfo">
    <span>{{$product['productName']}}</span>
    <span>{{$product['productPrice']}} $</span>
    </div>
    <div class="showdetails">
    @if($product['catId']==1)
    <span><a href="{{route('computers.show',$product['id'])}}">show details</a></span>
    @else
    <span><a href="{{route('accessories.show',$product['id'])}}">show details</a></span>
    @endif
    </div>  
    <div class="button" data-id="{{$product['id']}}">
       Add To Cart
    </div>
</div>
@endforeach
</div>
        
                    <ul class='paginationlist'>
                  
                    </ul>
        
</div>
@include('footer')



@endsection


