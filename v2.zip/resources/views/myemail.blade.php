<!DOCTYPE html>
<html>

<body>
    <h1 style="color:red">>Hy Mr {{ $data['name'] }}</h1>
    <h1>Yor email is {{$data['email']}}</h1>
    <p>the result is your are : {{ $data['message'] }}</p>
     <p>Thank you</p>
</body>
</html>