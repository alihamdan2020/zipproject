<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Cookie;
use Illuminate\Support\Facades\Session;
use App\Models\Cart;
use App\Models\OrderDetails;



class itemsController extends Controller
{
    
   
    public function index()        
    {   
       
    }

    public function create()
    {
     
    }

    public function store(Request $request)
    {
      
    }
    

    public function show($id)
    {

    }

    public function edit($id)
    {

    }

    public function update(Request $request, $id)
    {

    }

  

public function destroy($id)
    {
      //delete the id from temporary table, and the id passed from form   
      if(db::table("temp_carts")->count()!=1){    
      $deleItem=db::table("temp_carts")->where('productId',$id)->delete();
      $total=db::table("temp_carts")->count();
      session()->put("total",$total);
      //code below mean use the function check out - at bottom of this controller
      return $this->checkout();
     
    }
    }

    public static function showCart($items,$qty){

        $result ="<div class='content'>
                    <div class='headeofcontent'>
                    <h1>All</h1>
                    <p>Your Items</p>
                    </div>
        <div class='allitems'>";
        $i=0;
        foreach($items as $item){
     
        $result=$result."<div class='item'>
                <div class='itemimage'>
                <img src='".url('images/' .$item ->image)."')>
                </div>
                <div class='iteminfo'>
                <span>".$item-> productName."$</span>
                <span>".number_format($item ->productPrice)."$ </span>
                <span>".$qty[$i]." </span>
                <span>".number_format($qty[$i]*$item ->productPrice)." $</span>
                
               
                <form action='".route('items.destroy', $item->id)."' method='POST'>";
                $i++;
                $result.=csrf_field();           
                $result.=method_field('DELETE');
                if(count($items)==1)
                $result.="<button type='submit' disabled><i class='fas fa-minus-circle'></i></button>";
                else
                $result.="<button type='submit'><i class='fas fa-minus-circle'></i></button>";
                $result.="</form>
              
                </div></div>";
                
        }
        $result.="</div></div>";
        $i=0;
        return $result;
}


      function checkout(){
 
        $itempProducts=DB::table("temp_carts")->select("*")->get();
        $productIdArray=[];
        $productQty=[];
        //this for each,to make 2 array,one from only productId (we use it later) and one for the qty
        foreach($itempProducts as $itemByItem){
        array_push($productIdArray,$itemByItem->productId);
        array_push($productQty,$itemByItem->qty);
        }

               
        $allproducts = DB::table('products')
        ->select('*')
        //wherein mean select from id =... or id = ... or ....
        ->whereIn("id",$productIdArray)
        ->get();

        
        return view ("items.index",['specitems'=>$allproducts],['qty'=>$productQty]);
      }


      public function confirm(){
       
        $cart=new cart();
        $cart->userId=session()->get("userId");
        $cart->save();

        $Lastorder = DB::table('carts')->orderBy('created_at','desc')
        ->get()
        ->unique('userId')
        ->where('userId',session()->get('userId'));
        
        $itempProducts=DB::table("temp_carts")->select("*")->get();
        foreach($itempProducts as $item){
          $orderdetail=new OrderDetails();
          $orderdetail->orderId=$Lastorder[0]->orderId;
          $orderdetail->productId=$item->productId;
          $orderdetail->qty=$item->productId;
          $orderdetail->save();  
        }

             
        session()->pull("total");

       db::table("temp_carts")->truncate();

        
        return view("items.confirm");
      }

}
    


