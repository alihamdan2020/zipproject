<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Mail\contact;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\userController;
use App\Models\TempCart;



class HomeController extends Controller
{



    public function welcome()
    {
        $allproducts = DB::table('products')
            ->join('country', 'country.countryId', '=', 'products.countryId')
            ->select('*')
            ->Paginate(10);
        return view('welcome', ['allproducts' => $allproducts]);
    }


    
    function addToCart(Request $req)
    {
        if ($req->session()->has('user')) {

            $req->validate([
                'productId' => 'unique:temp_carts',
           ]);
            
           //create a temporary table just to insert productsId and qty
            $newTempCart = new TempCart();
            $productId = $req->input('productId');
            $qty = $req->input('txtQty');
            $newTempCart->productId=$productId;
            $newTempCart->qty=$qty;
            $newTempCart->save();
            
            //count to indicate the number of product that you click add to cart
            $total=db::table("temp_carts")->count();
            session()->put("total",$total);

            return redirect('/#loadHere');
        } else
            return redirect('/login');
    }
    public function dipslayCrateItems()
    {
    }
}
