<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\DB;

class accessoriesController extends Controller
{
    
    public function index()
    {
        $allproducts=DB::table('products')
        ->join('country', 'country.countryId', '=', 'products.countryId')
        ->select('*')
        ->where('catId',2)
        ->get();
        return View('accessories.index',['allproducts'=>$allproducts]);
    }

    
    public function create()
    {
        //
    }

   
    public function store(Request $request)
    {
    
    }

    
    public function show($id)
    {
        $product=Product::find($id);
        return view ('accessories.show',['oneproduct'=>$product]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
