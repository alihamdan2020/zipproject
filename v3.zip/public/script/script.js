
//add and minus qty
var up=document.getElementsByClassName('fa-arrow-circle-up');
upArray=Array.from(up);
upArray.forEach(function(up){
    up.addEventListener("click",function(){
        if(this.nextElementSibling.value<=4)
       this.nextElementSibling.value=parseInt(this.nextElementSibling.value)+1;
    
});
})
var down=document.getElementsByClassName('fa-arrow-circle-down');
downArray=Array.from(down);
downArray.forEach(function(down){
    down.addEventListener("click",function(){
        if(this.previousElementSibling.value>1)
      this.previousElementSibling.value=parseInt(this.previousElementSibling.value)-1;
    
});
})

//the condition below to set the value of attribute (value) of crate
let valueOfLocalStorage;

// if (localStorage.getItem("contentOfCrate")=="null")
// valueOfLocalStorage=0;
// else
// valueOfLocalStorage=localStorage.getItem("contentOfCrate");


//here we set the value of attribute (value) of crate
var cart=document.getElementsByClassName("fa-shopping-cart")[0];
// cart.setAttribute("value",valueOfLocalStorage);

//press add to cart button
var counter=0;
var btn = document.getElementsByClassName('button');
btnArray=Array.from(btn);
let products=[];

btnArray.forEach(function(btn){
    
    btn.addEventListener("click",function(){
        id=btn.getAttribute("data-id");
        qty=this.previousElementSibling.children[1].value;
        oneProduct={id,qty};
        counter+=1;
        localStorage.setItem("contentOfCrate",counter);
        cart.setAttribute("value",counter);
        products.push(oneProduct);
       
        localStorage.setItem("arrayOfItems",JSON.stringify(products));
       
});
});

// press the crate to display all items has been added to crate
cart.addEventListener("click",function(){
    
    localStorage.setItem("contentOfCrate",null);
    localStorage.setItem("arrayOfItems",JSON.stringify(products));
    document.cookie=("abc = " + JSON.stringify(products));
    
});

let del=document.getElementsByClassName("removeFromCrates");
var itemsToConfirm=[];
itemsToConfirm=JSON.parse(localStorage.getItem("arrayOfItems"));  
delArray=Array.from(del);
delArray.forEach(function(delLink){
    
    delLink.addEventListener("click",function(){
        var id=this.getAttribute("data-id");
         
        for(var i=0;i<(itemsToConfirm).length;i++)
        if((itemsToConfirm)[i]['id']==id)
        {
        itemsToConfirm.splice(i,1);
        this.parentElement.parentElement.remove();
        }
        
        //we remove the div that contain the link
        //since as the link it is not the direct child,we use twice parentElelemt
        //this.parentElement.parentElement.remove();
       
        //document.cookie=("abc = " + itemsToConfirm);
        //alert(itemsToConfirm);
       

        });

});


//press burger icon
var burger=document.getElementsByClassName("burger")[0];
var listheader=document.getElementsByClassName("listheader")[0];

burger.addEventListener("click",function(){
    if(getComputedStyle(listheader).display=="none")
    listheader.style.display="flex";
    else
    listheader.style.display="none";
});



//function to create a LI with data-value attribute to conatain value
//with class pageLink
function createItemList(name,value){
    let li=document.createElement('li');
    li.classList.add("pageLink");
    li.setAttribute("data-value",value);
    let linkText=document.createTextNode(name);
    li.appendChild(linkText);
    return li;
}

/*
function hideDiv(a,b,x){
    var p=Array.from(x);
    for(i=a;i<b;i++){
    p[i].style.display="none";
    }
}

//function to display few products(pagination)
function displayDiv() {
     var product=document.querySelectorAll(".product");
     var arrProduct=Array.from(product);
     var listnumber=document.querySelectorAll(".paginationlist");
     var totalNumberOfDiv=product.length;
     var limit=10;

   hideDiv(10,totalNumberOfDiv,product);

   for(i=Math.ceil(product.length/10);i>=1;i--)
    listnumber[0].appendChild(createItemList(i,i));
    
   

   var anch=document.querySelectorAll(".pageLink");
   anchArray=Array.from(anch);
   anchArray.forEach(function(elem){
       elem.addEventListener("click",function(){
       var t=this.getAttribute("data-value");
     
        arrProduct.filter(function(div,index){
            return index<t*10-10 || index>t*10-1;
           }).forEach(function(div){
            div.style.display="none";
           })

        arrProduct.filter(function(div,index){
            return index>=t*10-10 && index<=t*10-1;
           }).forEach(function(div){
            div.style.display="block";
           })
    
   
       })
   
   });
   
}
document.addEventListener("DOMContentLoaded", displayDiv());
*/
