<!DOCTYPE html>
<html>

<body>
    <h1 style="color:red">>Hy Mr <?php echo e($data['name']); ?></h1>
    <h1>Yor email is <?php echo e($data['email']); ?></h1>
    <p>the result is your are : <?php echo e($data['message']); ?></p>
     <p>Thank you</p>
</body>
</html><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views//myemail.blade.php ENDPATH**/ ?>