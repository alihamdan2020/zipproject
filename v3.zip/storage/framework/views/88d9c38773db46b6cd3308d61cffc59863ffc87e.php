
<h1>

<?php $__currentLoopData = Session::get('orders'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    product Id : <?php echo e($order[0]); ?>

    Qty :<?php echo e($order[1]); ?>

    <hr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</h1><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/items/checkout.blade.php ENDPATH**/ ?>