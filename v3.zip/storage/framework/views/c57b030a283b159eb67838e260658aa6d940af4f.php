<?php
use App\Http\Controllers\computerController;
?>

<?php $__env->startSection('title'); ?>
Index page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo computerController::displayProducts($allproducts,"Products"); ?>
<?php echo e($allproducts->links()); ?>

<?php echo computerController::displaySection(); ?>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/welcome.blade.php ENDPATH**/ ?>