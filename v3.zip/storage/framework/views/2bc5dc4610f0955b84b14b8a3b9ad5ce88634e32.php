

<?php $__env->startSection('title'); ?>
Contact Us Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h3>Contact Us</h3>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolore eaque facere debitis nulla exercitationem, excepturi non assumenda sunt asperiores mollitia perspiciatis distinctio sequi minima et quasi quidem iusto tempora ea!</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/contactus.blade.php ENDPATH**/ ?>