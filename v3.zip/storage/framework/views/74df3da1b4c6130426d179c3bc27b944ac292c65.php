;

<?php $__env->startSection('content'); ?>
<div class="content">
<div class="messageConfirm">
    <p>Congrats Your Order has Been Done</p>
    <a href="/">Home</a>
</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/items/confirm.blade.php ENDPATH**/ ?>