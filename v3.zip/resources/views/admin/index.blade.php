<ul>
    
    <li><a href="{{route('computers.create')}}">create new computer</a></li>
    <li><a href="{{route('computers.edit',1)}}">edit exist computer</a></li>
</ul>

<form action="{{route('clickme')}}" method="POST">
@csrf 

<input type="text" name="txtid">
<button type="submit">submit</button>
</form>