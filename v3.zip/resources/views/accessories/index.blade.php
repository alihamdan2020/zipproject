<?php
use App\Http\Controllers\computerController;
?>

@extends('layout')

@section('content')
<?php echo computerController::displayProducts($allproducts,"Accessories"); ?>

<?php echo computerController::displaySection(); ?>

</div>
@endsection


@section('title')
Accessories page
@endsection