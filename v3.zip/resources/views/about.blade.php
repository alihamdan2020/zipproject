@extends('layout')

@section('title')
About Us Page
@endsection

@section('content')
@include('partial/test')
<h3>About Us</h3>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolore eaque facere debitis nulla exercitationem, excepturi non assumenda sunt asperiores mollitia perspiciatis distinctio sequi minima et quasi quidem iusto tempora ea!</p>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolore eaque facere debitis nulla exercitationem, excepturi non assumenda sunt asperiores mollitia perspiciatis distinctio sequi minima et quasi quidem iusto tempora ea!</p>
@endsection