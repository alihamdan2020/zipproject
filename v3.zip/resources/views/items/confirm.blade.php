@extends('layout');

@section('content')
<div class="content">
<div class="messageConfirm">
    <p>Congrats Your Order has Been Done</p>
    <a href="/">Home</a>
</div>

</div>

@endsection