
<?php
use App\Http\Controllers\itemsController;
?>
@extends('layout')

@section('content')
<?php echo itemsController::showCart($specitems,$qty); ?>
<br><br><br><br><br><br>
<form action="{{route('confirm')}}" method="POST">
    @csrf
 <button type="submit" title="Confirm">Confirm</button>
</form>

<br>

</div>

@endsection


@section('title')
Computers page
@endsection

