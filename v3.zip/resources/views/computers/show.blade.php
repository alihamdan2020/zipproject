@extends('layout')
@section('content')
<style>
    .productdetail{
        display: flex;
        padding:20px;
        font-size: 12px;
    }
    .productinfo{
        border:1px solid green;
        width:50%;
        padding:20px
    }
    .productinfo span{
        color:brown;
    }
    .productinfo p{
        color:#ccc;
        padding-left:15px;
    }
    .productimage{
        width:50%;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .productimage img{
        width:50%;
        max-width: 100%;
    }

</style>
<div class="productdetail">
    <div class="productinfo">
        <span>Product Name</span>
<p>{{$oneproduct-> productName}}</p>
<span>Product Dexription</span>
<p>{{$oneproduct-> productDesc}}</p>
<span>Product Price</span>
<p>{{$oneproduct-> productPrice}} $</p>
</div>
<div class="productimage">
    <img src="{{url('images/' . $oneproduct ->image)}}" alt="">
</div>
</div>
<div class="back">
    <a href="{{route('computers.index')}}">back to computers page</a>
</div>
@endsection