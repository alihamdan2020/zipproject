<?php

use App\Http\Controllers\computerController;
?>
@extends('layout')

@section('content')
<?php echo computerController::displayProducts($allproducts, "Computers"); ?>

<?php echo computerController::displaySection(); ?>

</div>

@endsection


@section('title')
Computers page
@endsection