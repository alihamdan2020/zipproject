@if (session()->has("message"))
    <p x-data="{show:true}" x-init="setTimeout(() => show =false ,3000)" x-show="show"  style='position:fixed;top:0;left:50%;transform:translateX(-50%);border:red;z-index:1'>{{session()->get("message")}}</p>
    @endif