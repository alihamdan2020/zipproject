@extends('layout')

@section('title')
Contact Us Page
@endsection

@section('content')
<h3>Contact Us</h3>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolore eaque facere debitis nulla exercitationem, excepturi non assumenda sunt asperiores mollitia perspiciatis distinctio sequi minima et quasi quidem iusto tempora ea!</p>
@endsection