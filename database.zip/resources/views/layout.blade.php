<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="{{url('css/style.css')}}" rel="stylesheet"></link>
    <title>@yield('title')</title>
</head>

<body>
<div class="container">
    <div class="aboveheader">
        
        @if(!session()->has('user'))
        <span><a href="{{route('login.index')}}">Log In</a></span>
        @else
        <span><a href="{{route('logout')}}">Log Out</a></span>
        @endif

    </div>
    <div class="header">
        <img src="{{url('images/logo.png')}}" alt="">
        <ul class="listheader">
            <li><a href="{{route('home')}}">Home</a></li>
            <li><a href="{{route('computers.index')}}">Computers</a></li>
            <li><a href="{{route('accessories.index')}}">Accessories</a></li>
            <li><a href="{{route('about')}}">About Us</a></li>
            <li><a href="{{route('contact')}}">Contact Us</a></li>
        </ul>
    </div>
    @if (request()->is('/'))
    <div class="landing">
        <h1>All You need by one visit</h1>
    </div>
    @else
        @if (request()->is('computers'))
        <div class="landing">
            <h1>Ommak</h1>
        </div>
        @endif
    @endif
@yield('content')
</div> 

</body>
</html>