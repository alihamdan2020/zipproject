@extends('layout')

@section('content')
<div class="content">
<h1>Log In</h1>    
<div class="formdiv">
    <form action="{{route('search')}}" method="post">
    @csrf
        <div>
            <label for="userrName">User Name</label>
            <input name="userName" value="{{old('userName')}}" id="userrName" type="text">
            <span>
                @error('userName')
                {{$message}}
                @enderror
            </span>
        </div>
        <div>
            <label for="userPass">Password</label>
            <input name="userPass" value="{{old('userPass')}}" id="userPass" type="text">
            <span>
                @error('userPass')
                {{$message}}
                @enderror
            </span>
        </div>
        <div>
            <button type="submit">Submit</button>
            <span><a href="#">new register</a></span>
        </div>
        <div>
            <span class="errmsg">
            @error('error')
                {{$message}}
            @enderror
            </span>
        </div>

    </form>
</div>
</div>
@include('footer')
@endsection
