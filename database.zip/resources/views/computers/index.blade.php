@extends('layout')

@section('content')
<div class="content">
<h1>Display All Computers</h1>
<div class="allproducts">
@foreach ($allproducts as $product)
<div class="product">
<div class="productimage">
    <img src="{{url('images/' . $product->image)}}" alt="">
    </div>
    <div class="productinfo">
    <span>{{$product ->productName}}</span>
    <span>{{$product ->productPrice}} $</span>
    <span>{{$product ->productDesc}}</span>
    <span>{{$product ->countryName}}</span>
    <span><a href="{{route('computers.show',$product->id)}}">show details</a></span>

</div>
</div>
@endforeach
</div>
</div>
@include('footer')
@endsection


@section('title')
Computers page
@endsection