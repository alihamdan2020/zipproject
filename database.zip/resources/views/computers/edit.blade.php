@extends('layout')
@section('title')
Edit Existing Computer page
@endsection

@section('content')
<div class="content">
<div class="formdiv">

    <form action="{{route('computers.update', ['computer'=>$comp->id])}}" method="post">
    @csrf
    @method('PUT')
        <div>
            <label for="computerName">Computer Name</label>
            <input name="computerName" value="{{$comp->productName}}" id="computerName" type="text">
            <span>
                @error('computerName')
                {{$message}}
                @enderror
            </span>
        </div>
        <div>
            <label for="computerPrice">Computer Price</label>
            <input name="computerPrice" value="{{$comp->productPrice}}" id="computerPrice" type="text">
            <span>
                @error('computerPrice')
                {{$message}}
                @enderror
            </span>
        </div>
        <div>
            <label for="computerDesc">Computer Description</label>
            <input name="computerDesc" value="{{$comp->productDesc}}" id="computerDesc" type="text">
            <span>
                @error('computerDesc')
                {{$message}}
                @enderror
            </span>
        </div>
        <div>
            <label for="computerCountry">Computer Country</label>
            <select name="computerCountry" id="">
                @foreach($countries as $country)
                <option value="{{$country->countryId}}">{{$country->countryName}}</option>
                @endforeach
            </select>
            
        </div>

        <div>
            <button type="submit">Submit</button>
        </div>

    </form>
</div>
</div>
@include('footer')
@endsection




