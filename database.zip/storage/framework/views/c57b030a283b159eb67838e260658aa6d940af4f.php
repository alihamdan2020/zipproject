<?php $__env->startSection('title'); ?>
Index page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="headeofcontent">
    <h1>All</h1>
    <p> Categories</p>
    </div>
    <div class="allproducts">
    <?php $__currentLoopData = $allproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="product">
    <div class="productimage">
    <img src="<?php echo e(url('images/' . $product['image'])); ?>" alt="">
    </div>
    <div class="productinfo">
    <span><?php echo e($product['productName']); ?></span>
    <span><?php echo e($product['productPrice']); ?> $</span>
    <span><?php echo e($product['productDesc']); ?></span>
    <?php if($product['catId']==1): ?>
    <span><a href="<?php echo e(route('computers.show',$product['id'])); ?>">show details</a></span>
    <?php else: ?>
    <span><a href="<?php echo e(route('accessories.show',$product['id'])); ?>">show details</a></span>
    <?php endif; ?>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/welcome.blade.php ENDPATH**/ ?>