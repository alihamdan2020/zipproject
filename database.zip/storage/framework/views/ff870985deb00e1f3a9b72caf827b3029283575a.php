

<?php $__env->startSection('content'); ?>
<div class="content">
<h1>Display All Computers</h1>
<div class="allproducts">
<?php $__currentLoopData = $allproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="product">
<div class="productimage">
    <img src="<?php echo e(url('images/' . $product->image)); ?>" alt="">
    </div>
    <div class="productinfo">
    <span><?php echo e($product ->productName); ?></span>
    <span><?php echo e($product ->productPrice); ?> $</span>
    <span><?php echo e($product ->productDesc); ?></span>
    <span><?php echo e($product ->countryName); ?></span>
    <span><a href="<?php echo e(route('computers.show',$product->id)); ?>">show details</a></span>

</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
Computers page
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\jmlaravel\resources\views/computers/index.blade.php ENDPATH**/ ?>