<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\ViewErrorBag;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use PhpParser\Node\Stmt\Else_;

class computerController extends Controller
{
    
    public function index()
    {
   //return View('computers.index',['allproducts'=>Product::all()]);
   //$allproducts=Product::where('catId',1)::get();
   $allproducts=DB::table('products')
   ->join('country', 'country.countryId', '=', 'products.countryId')
   ->select('*')
   ->where('catId',1)
   ->get();
     
   return View('computers.index',['allproducts'=>$allproducts]);
    }

    
    public function create()
    {
        $country=DB::table('country')->get();
        return view ('computers.create',['countries'=>$country]);
    }

    
    public function store(Request $request)
    {

     $request ->validate([
        'computerName'=>'required'  ,
        'computerPrice' => ['required','integer'],
        'computerDesc'=>'required'
     ]);
    $comp=new Product();
    $comp ->productName =strip_tags($request ->input('computerName'));
    $comp ->productPrice = strip_tags($request ->input('computerPrice'));
    $comp ->productDesc = strip_tags($request ->input('computerDesc'));
    $comp ->countryId = $request ->input('computerCountry');
    $comp ->catId =1;
        
    $comp->save();

    return redirect()->route('computers.index');
    }

  
    public function show($id)
    {
        $allproducts=DB::table('products')->where('id',$id)->get();
        return view('computers.show',['oneproduct'=>$allproducts[0]]);
    }

    public function edit($id)
    {
        $comp=Product::find($id);
        $country=DB::table('country')->get();
        return view('computers.edit',['comp'=>$comp],['countries'=>$country]);
    }

    public function update(Request $request, $id)
    {
        $request ->validate([
            'computerName'=>'required'  ,
            'computerPrice' => ['required','integer'],
            'computerDesc'=>'required'
         ]);

         $product=product::find($id);
         $product ->productName =strip_tags($request ->input('computerName'));
        $product ->productPrice = strip_tags($request ->input('computerPrice'));
        $product ->productDesc = strip_tags($request ->input('computerDesc'));
        $product ->countryId = $request ->input('computerCountry');
        $product ->catId =1;
        
        $product->save();
       
      return redirect()->route('admin.index');
    }


    public function destroy($id)
    {
        //
    }

    

}
