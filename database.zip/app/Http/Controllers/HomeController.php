<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class HomeController extends Controller
{
   public function welcome() {
    return view ('welcome',['allproducts'=>Product::all()]);
   }
}
