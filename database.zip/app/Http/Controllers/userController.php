<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use    App\Models\User;
use Illuminate\Support\Facades\DB;
use App\Models\Product;

class userController extends Controller
{
    public function index(){
        return view ("login.register");
    }

    public function searchUser(Request $request){
        $request ->validate([
            'userName'=>'required',
            'userPass' => 'required',
         ]);

        $name=$request->input('userName');
        $pass=$request->input('userPass');
        $user=DB::table('users')
        ->select('*')
        ->where('name',$name)
        ->where('password',$pass)
        ->get();
        
        if(count($user)==1){
        session()->put('user',1);
        return redirect ('/');
        }
        else
        {
        $err="Wrong User Name and Password";
        return redirect()->back()
        ->withErrors(['error'=>$err])
        ->withInput();
        }
    }

    public function logout(){
        session()->pull('user');
        return redirect ('/');
    }
}
