<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="conent">
        <div class="header">
            <?php if(auth()->guard()->guest()): ?>
                <ul>
                    <li><a href="<?php echo e(route('login')); ?>">Log In</a></li>
                    <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                </ul>
           

            <?php else: ?>
            <ul>
                <li><a href="<?php echo e(route('logout')); ?>">Log out</a></li>
            </ul>
            <?php endif; ?>
        </div>
        
    </div>
</body>
</html><?php /**PATH C:\xampp1\htdocs\newProjectLaravel\resources\views/main.blade.php ENDPATH**/ ?>