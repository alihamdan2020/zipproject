<?php
use Illuminate\Support\Facades\Session;
?>
<h1>dashboard</h1>
<?php echo e(session::get("message")); ?><?php /**PATH C:\xampp1\htdocs\newProjectLaravel\resources\views/dashboard.blade.php ENDPATH**/ ?>