<div class="form-login">
    <form action="<?php echo e(route('validateLogin')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="name">
            <input type="text" name="name" value="<?php echo e(old('name')); ?>">
            <span>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>    
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
        </div>
        <div class="password">
            <input type="password" name="password" value="<?php echo e(old('password')); ?>">
            <span>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>    
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
        </div>
        <div class="submit">
            <button type="submit">Submit</button>
        </div>

    </form>
</div><?php /**PATH C:\xampp1\htdocs\newProjectLaravel\resources\views/user/login.blade.php ENDPATH**/ ?>