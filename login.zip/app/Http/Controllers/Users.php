<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Session;

class Users extends Controller
{
     function login(){
        return view('login');
    }
     function logout(){
        session::flush();
        auth::logout();
        return redirect('login');
    }
     function register(){
        return view('register') ;
    }

    function validateregister(Request $req){
        $req->validate([
            'name'      =>'required',
            'email'     =>'required|email|unique:users',
            'password'  =>'required|min:5'
        ]);
        $data=$req->all();
        User::create([
                    'name' => $data['name'],
                    'email' => $data['email'],
                    'password' => hash::make($data['password']),
       ]);
       return redirect('login')->with('message','Your credential has bedd added good, log in please');
    }

    function validateLogin(Request $req){

        $req->validate([
            'email'     =>'required|email',
            'password'  =>'required|min:5'
        ]);

        $credential=$req->only('email','password');

        if(auth::attempt($credential))
        return redirect ('dashboard')->with("message","ok you are welcome");

        return redirect('login')->with("message","wrong user name otr password");
        
    }


    function dashboard(){
        if(auth::check())
        return view ("dashboard");
        else
        return redirect('login')->with("message","should login");
    }


}
