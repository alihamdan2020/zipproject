<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Users;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('main');
});

route::controller(Users::class)->group(function(){

route::get('login','login')->name('login');
route::get('register','register')->name('register');
route::get('logout','logout')->name('logout');
route::get('dashboard','dashboard')->name('dashboard');
route::get('logout','logout')->name('logout');

route::post('validate_Log_In','validatelogin')->name('validateLogin');
route::post('validate_Register','validateregister')->name('validateregister');


});


