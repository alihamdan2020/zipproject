<?php
use Illuminate\Support\Facades\Session;
?>
<h1>dashboard</h1>
{{session::get("message")}}