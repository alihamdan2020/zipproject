<div class="form-login">
    <form action="{{route('validateregister')}}" method="post">
        @csrf
        <div class="name">
            <input type="text" name="name" value="{{old('name')}}">
            <span>
            @error('name')    
                {{$message}}
            @enderror
            </span>
        </div>
        <div class="email">
            <input type="text" name="email" value="{{old('email')}}">
            <span>
            @error('email')    
                {{$message}}
            @enderror
            </span>
        </div>
        <div class="password">
            <input type="password" name="password" value="{{old('password')}}">
            <span>
            @error('password')    
                {{$message}}
            @enderror
            </span>
        </div>
        <div class="submit">
            <button type="submit">Submit</button>
        </div>

    </form>
</div>